
import Earth from "./components/Earth";

function App() {
  return (
    <div className="App">
      <Earth />
    </div>
  );
}

export default App;
