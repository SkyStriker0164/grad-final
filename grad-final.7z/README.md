### Links:

project: https://github.com/SkyStriker0164/grad-final 
video: https://www.youtube.com/watch?v=FGKvRAhOMUk&t=1s 
process book: [text](<dv process book.docx>)